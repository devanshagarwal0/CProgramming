#include<stdio.h>
int main(){
    int a=5;
    printf("%d \n",a);

    float b=6;
    printf ("%f\n",b);

    char c ='A';
    printf("%c\n",c);

    return 0;
    
}