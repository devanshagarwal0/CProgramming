#include <stdio.h>

int main() {
    int l,b;

    printf ("Enter the length");
    
    scanf ("%d",&l);

    printf ("Enter the breath");

    scanf ("%d",&b);

    printf ("perimeter of rectangle : %d",2*(l+b));

    return 0;
}